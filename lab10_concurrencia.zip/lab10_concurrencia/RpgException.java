/**
 * Excepción base chequeada del sistema RPG.
 */
public class RpgException extends Exception {

    public RpgException(String mensaje) {
        super(mensaje);
    }
}
