public class PersonajeDerrotadoException extends RpgException {

    public PersonajeDerrotadoException(String nombre) {
        super("El personaje '" + nombre + "' está derrotado y no puede realizar esta acción.");
    }
}
