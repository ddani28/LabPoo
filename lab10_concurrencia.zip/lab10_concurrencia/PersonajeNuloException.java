/**
 * Excepción NO chequeada: representa un error de programación
 * (se intentó usar un personaje nulo).
 */
public class PersonajeNuloException extends RuntimeException {

    public PersonajeNuloException(String accion) {
        super("Personaje nulo en la acción: " + accion);
    }
}
