public class Main {
    public static void main(String[] args) {
        System.out.println("=== RPG — Sistema con Manejo de Excepciones ===");

        MotorCombate motor = new MotorCombate();

        Druida druida = new Druida("Sylva", 8, 300, 100, 40, 150);
        Druida druida2 = new Druida("Ronan", 5, 250, 80, 30, 100);
        Nigromante nigromante = new Nigromante("Malachar", 10, 200, 60, 5);
        Arquero sinFlechas = new Arquero("Legolas", 6, 150, "Arco Largo", 0, 95);

        // Escenario 1: turno normal sin excepción
        motor.ejecutarTurno(druida, nigromante);

        // Escenario 2: personaje derrotado intenta atacar
        try {
            druida.recibirDanio(9999);
        } catch (AccionInvalidaException e) {
            System.out.println(e.getMessage());
        }
        motor.ejecutarTurno(druida, nigromante);

        // Escenario 3: arquero sin flechas
        motor.ejecutarTurno(sinFlechas, nigromante);

        // Escenario 4: curar aliado derrotado
        System.out.println("\n-- Intento de curar aliado derrotado --");
        try {
            druida2.curarAliado(druida);
        } catch (RpgException e) {
            System.out.println("No se pudo curar: " + e.getMessage());
        }

        // Escenario 5: daño negativo con finally
        System.out.println("\n-- Bloque manual try-catch-finally --");
        try {
            nigromante.recibirDanio(-50);
        } catch (AccionInvalidaException e) {
            System.out.println("Capturado: " + e.getMessage());
        } finally {
            System.out.println("El bloque finally siempre se ejecuta.");
        }

        // Escenario 6: bitácora completa
        motor.mostrarBitacora();
    }
}
